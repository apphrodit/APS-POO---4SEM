package br.edu.unifaj.cc.poo.SistemaAcademiaAPS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaAcademiaApsApplicationTests {

	@Test
	void contextLoads() {
	}

}
