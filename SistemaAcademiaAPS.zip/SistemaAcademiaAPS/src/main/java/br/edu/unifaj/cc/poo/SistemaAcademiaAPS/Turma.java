package br.edu.unifaj.cc.poo.SistemaAcademiaAPS;

import lombok.Data;

@Data
public class Turma {

    private Long id;
    private String data;
    private String horario;
    private int capacidadeMaxima;
    private String status;

    public boolean verificarDisponibilidade() {
        return capacidadeMaxima > 0;
    }

    public void encerrarTurma() {
        status = "ENCERRADA";
    }
}