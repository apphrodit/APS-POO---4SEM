package br.edu.unifaj.cc.poo.SistemaAcademiaAPS;

import lombok.Data;

@Data
public class FichaTreino {

    private Long id;
    private String dataCriacao;
    private String objetivo;
    private String observacoes;
    private String status;

    public void ativarFicha() {
        status = "ATIVA";
    }

    public void finalizarFicha() {
        status = "FINALIZADA";
    }
}