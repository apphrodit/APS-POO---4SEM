package br.edu.unifaj.cc.poo.SistemaAcademiaAPS;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public abstract class Pessoa {

    private Long id;
    private String nome;
    private String cpf;
    private String telefone;
    private String email;
}
