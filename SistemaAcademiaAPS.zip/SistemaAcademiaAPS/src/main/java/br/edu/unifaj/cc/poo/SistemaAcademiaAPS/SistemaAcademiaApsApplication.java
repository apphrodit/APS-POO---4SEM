package br.edu.unifaj.cc.poo.SistemaAcademiaAPS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaAcademiaApsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaAcademiaApsApplication.class, args);
	}

}
