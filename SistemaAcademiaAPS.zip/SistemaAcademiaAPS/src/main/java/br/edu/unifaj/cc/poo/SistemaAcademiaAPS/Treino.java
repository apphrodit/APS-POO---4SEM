package br.edu.unifaj.cc.poo.SistemaAcademiaAPS;

import lombok.Data;

@Data
public class Treino {

    private Long id;
    private String nome;
    private String descricao;
    private String diaSemana;

    public void iniciarTreino() {
        System.out.println("Treino iniciado.");
    }

    public void finalizarTreino() {
        System.out.println("Treino finalizado.");
    }
}