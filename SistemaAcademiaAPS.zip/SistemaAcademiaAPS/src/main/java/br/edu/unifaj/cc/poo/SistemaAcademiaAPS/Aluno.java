package br.edu.unifaj.cc.poo.SistemaAcademiaAPS;

import lombok.Data;

@Data
public class Aluno extends Pessoa {

    private String dataNascimento;
    private String objetivo;
    private String dataMatricula;
    private String status;
}