package br.edu.unifaj.cc.poo.SistemaAcademiaAPS;

import lombok.Data;

@Data
public class Matricula {

    private Long id;
    private String dataInicio;
    private String dataFim;
    private String status;

    public void ativar() {
        status = "ATIVA";
    }

    public void cancelar() {
        status = "CANCELADA";
    }

    public boolean verificarAtiva() {
        return "ATIVA".equals(status);
    }
}