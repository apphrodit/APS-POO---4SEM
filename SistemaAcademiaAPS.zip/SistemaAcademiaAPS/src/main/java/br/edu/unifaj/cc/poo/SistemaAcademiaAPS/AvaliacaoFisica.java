package br.edu.unifaj.cc.poo.SistemaAcademiaAPS;

import lombok.Data;

@Data
public class AvaliacaoFisica {

    private Long id;
    private String dataAvaliacao;
    private double peso;
    private double altura;
    private double percentualGordura;
    private String observacoes;

    public double calcularIMC() {
        return peso / (altura * altura);
    }

    public void registrarAvaliacao() {
        System.out.println("Avaliação física registrada.");
    }
}