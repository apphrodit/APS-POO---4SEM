package br.edu.unifaj.cc.poo.SistemaAcademiaAPS;

import lombok.Data;

@Data
public class Exercicio {

    private Long id;
    private String nome;
    private String grupoMuscular;
    private String descricao;

    public void consultarExercicio() {
        System.out.println("Consultando exercício.");
    }
}