package br.edu.unifaj.cc.poo.SistemaAcademiaAPS;

import lombok.Data;

@Data
public class ItemTreino {

    private Long id;
    private int series;
    private int repeticoes;
    private double carga;
    private int intervaloSegundos;

    public double calcularVolume() {
        return series * repeticoes * carga;
    }
}