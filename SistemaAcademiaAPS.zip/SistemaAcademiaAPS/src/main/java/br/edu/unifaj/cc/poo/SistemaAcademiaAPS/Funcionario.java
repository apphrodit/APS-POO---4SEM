package br.edu.unifaj.cc.poo.SistemaAcademiaAPS;

import lombok.Data;

@Data
public class Funcionario extends Pessoa {

    private String cargo;
    private double salario;
    private String dataAdmissao;
    private String status;

    public boolean verificarStatus() {
        return "ATIVO".equals(status);
    }

    public double calcularSalario() {
        return salario;
    }
}