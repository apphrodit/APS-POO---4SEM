package br.edu.unifaj.cc.poo.SistemaAcademiaAPS;

import lombok.Data;

@Data
public class Plano {

    private Long id;
    private String nome;
    private String descricao;
    private double valorMensal;
    private int duracaoMeses;

    public double calcularValorTotal() {
        return valorMensal * duracaoMeses;
    }

    public boolean verificarPlanoAtivo() {
        return duracaoMeses > 0;
    }
}