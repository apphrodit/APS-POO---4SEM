package br.edu.unifaj.cc.poo.SistemaAcademiaAPS;

import lombok.Data;

@Data
public class Pagamento {

    private Long id;
    private String dataPagamento;
    private double valor;
    private String formaPagamento;
    private String status;

    public void confirmarPagamento() {
        status = "CONFIRMADO";
    }

    public boolean verificarPagamento() {
        return "CONFIRMADO".equals(status);
    }
}