package br.edu.unifaj.cc.poo.SistemaAcademiaAPS;

import lombok.Data;

@Data
public class Agendamento {

    private Long id;
    private String dataAgendamento;
    private String status;

    public void confirmarAgendamento() {
        status = "CONFIRMADO";
    }

    public void cancelarAgendamento() {
        status = "CANCELADO";
    }
}