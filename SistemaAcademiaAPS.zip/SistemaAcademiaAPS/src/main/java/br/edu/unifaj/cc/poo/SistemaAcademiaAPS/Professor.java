package br.edu.unifaj.cc.poo.SistemaAcademiaAPS;

import lombok.Data;

@Data
public class Professor extends Funcionario {
    private String cref;
    private String especialidade;
}
