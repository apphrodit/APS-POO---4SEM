package br.edu.unifaj.cc.poo.SistemaAcademiaAPS;

import lombok.Data;

@Data
public class Aula {

    private Long id;
    private String nome;
    private String descricao;
    private int duracaoMinutos;
    private String nivel;

    public void iniciarAula() {
        System.out.println("Aula iniciada.");
    }

    public void finalizarAula() {
        System.out.println("Aula finalizada.");
    }
}