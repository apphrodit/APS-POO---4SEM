package br.edu.unifaj.cc.poo.SistemaAcademiaAPS;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;

@Repository
public class PessoaDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public Pessoa incluir(Pessoa p) {
        try {
            Connection con = jdbcTemplate.getDataSource().getConnection();

            String sql = "INSERT INTO pessoa (nome, cpf, telefone, email) VALUES (?, ?, ?, ?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, p.getNome());
            ps.setString(2, p.getCpf());
            ps.setString(3, p.getTelefone());
            ps.setString(4, p.getEmail());

            ps.executeUpdate();

            con.close();

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return p;
    }

}